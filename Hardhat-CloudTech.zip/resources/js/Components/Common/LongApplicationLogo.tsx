export default function LongApplicationLogo(){
    return <>
        <img width={'200px'} src={'storage/logo%20ai.png'} alt={''} />
        </>
}
