import { jsx } from "react/jsx-runtime";
function ApplicationLogo(props) {
  return /* @__PURE__ */ jsx("img", { src: "storage/logo.png", ...props, alt: "Hardhat-CloudTech", height: "80px" });
}
export {
  ApplicationLogo as A
};
