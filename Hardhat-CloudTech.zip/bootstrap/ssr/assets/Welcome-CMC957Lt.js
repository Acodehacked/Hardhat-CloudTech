import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { useEffect, useState, useRef } from "react";
import { Link, Head } from "@inertiajs/react";
import { A as ApplicationLogo } from "./ApplicationLogo-BoCt_erM.js";
import { ArrowRight, ChevronDown, LucideLink2, Menu } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
const BR = "10";
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
const useClickOutside = (ref, callback, addEventListener = true) => {
  const handleClick = (event) => {
    if (ref.current && !ref.current.contains(event.target)) {
      callback();
    }
  };
  useEffect(() => {
    if (addEventListener) {
      document.addEventListener("click", handleClick);
    }
    return () => {
      document.removeEventListener("click", handleClick);
    };
  });
};
function StandardLinkButton({ link, text, className }) {
  return /* @__PURE__ */ jsx(Link, { className: cn("bg-yellow-400 hover:translate-y-[-2px] transition-all duration-500  px-4 py-2 flex text-center", className, `rounded-[${BR}px]`), href: route(link), children: text });
}
const UserLinks = [
  {
    title: "Our Solutions",
    subtext: "What's our solutions",
    paragraph: "Discover the importance of connecting everyone and everything on the same platform.",
    route: "our-solutions-overview",
    sub: [
      {
        title: "Resource Management",
        route: "resource-tracking"
      }
    ]
  },
  {
    title: "Who we serve",
    route: "who-we-serve-overview",
    sub: [
      {
        title: "Contractors",
        route: "who-we-serve-1"
      },
      {
        title: "Clients",
        route: "who-we-serve-1"
      }
    ]
  },
  {
    title: "Resources",
    route: "resources-overview",
    sub: [
      {
        title: "Success Stories",
        route: "resources-1"
      },
      {
        title: "Clients",
        route: "who-we-serve-1"
      }
    ]
  }
];
function LoginButton({ text, link, className, linkClass, icon }) {
  return /* @__PURE__ */ jsx(motion.div, { className: cn("text-white", className), children: /* @__PURE__ */ jsxs(Link, { className: cn("bg-primary hover:translate-y-[-2px] transition-all w-full p-4 flex items-center", linkClass, `rounded-[${BR}px]`), href: route(link), children: [
    /* @__PURE__ */ jsx("span", { children: text }),
    icon && /* @__PURE__ */ jsx(ArrowRight, { size: 18 })
  ] }) });
}
function GuestHome({ children, logged }) {
  const [SelectedIndex, setSelectedIndex] = useState(-1);
  const navRef = useRef(null);
  const [navOpen, setnavOpen] = useState(false);
  useClickOutside(navRef, () => {
    setSelectedIndex(-1);
  });
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col relative bg-zinc-50", children: [
    /* @__PURE__ */ jsx("div", { className: "[#002349] bg-primary fixed z-[99] top-0 left-0 right-0", children: /* @__PURE__ */ jsxs("nav", { className: "flex screen items-center p-2 justify-between ", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 p-2", children: [
        /* @__PURE__ */ jsx(Link, { href: "/", children: /* @__PURE__ */ jsx(ApplicationLogo, { className: "w-[40px] fill-current text-gray-500" }) }),
        /* @__PURE__ */ jsx("h3", { className: "text-white text-xl font-extrabold", children: "HardHat Cloud Tech" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxs("div", { ref: navRef, className: cn("items-center md:flex-row flex-col md:relative absolute md:top-0 top-[60px] md:bg-transparent bg-white left-0 right-0 md:h-auto md:flex hidden h-[calc(100vh-60px)] z-[5]", navOpen ? "flex" : "hidden"), children: [
          UserLinks.map((link, index) => {
            return /* @__PURE__ */ jsxs("div", { onClick: () => setSelectedIndex((prev) => prev != index ? index : -1), className: "md:w-auto w-full select-none relative", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex w-full outline-none text-zinc-900 md:text-[16px] text-[18px] md:text-white md:justify-normal justify-between p-4 text-sm md:hover:bg-[rgba(0,0,0,0.1)] hover:bg-[rgba(0,0,0,0.05)]", children: [
                /* @__PURE__ */ jsx("span", { className: "", children: link.title }),
                /* @__PURE__ */ jsx(ChevronDown, { size: 19, className: "opacity-60" })
              ] }),
              /* @__PURE__ */ jsx(AnimatePresence, { children: SelectedIndex == index && /* @__PURE__ */ jsx(motion.div, { initial: { y: -20, opacity: 0, scale: 0.9 }, animate: { opacity: 1, scale: 1, y: 0 }, className: cn(`flex flex-col bg-secondary overflow-hidden rounded-sm h-[${link.sub.length}px] md:fixed md:top-[64px] top-0 relative`), children: link.sub.map((sublink, index2) => {
                return /* @__PURE__ */ jsx(Link, { className: "min-h-[50px] min-w-[200px] hover:bg-[rgba(0,0,0,0.05)]  flex items-center px-5", href: "/", children: /* @__PURE__ */ jsxs("span", { className: "flex gap-2 items-center", children: [
                  /* @__PURE__ */ jsx(LucideLink2, { size: 20 }),
                  sublink.title
                ] }) }, index2);
              }) }) })
            ] }, index);
          }),
          /* @__PURE__ */ jsx(LoginButton, { linkClass: "w-full justify-between", className: "md:hidden w-full p-4 mt-0", text: "Login / SignUp", link: "home" })
        ] }),
        /* @__PURE__ */ jsx(LoginButton, { icon: false, linkClass: "w-full justify-between bg-yellow-500 text-black py-2", className: "", text: "Login / SignUp", link: "home" }),
        /* @__PURE__ */ jsx(Menu, { size: 35, onClick: () => setnavOpen((prev) => !prev), className: "text-white hover:bg-[rgba(0,0,0,0.4)] p-1" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx("div", { className: "w-full min-h-[100vh]", children })
  ] });
}
function Welcome() {
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs(GuestHome, { logged: false, children: [
    /* @__PURE__ */ jsx(Head, { title: "Home" }),
    /* @__PURE__ */ jsxs("section", { className: "flex flex-col max-h-[100vh] h-full pt-14 relative overflow-hidden", children: [
      /* @__PURE__ */ jsxs("div", { className: "h-full text-white md:bg-transparent bg-primary py-10 md:absolute max-w-[1200px] w-full mx-auto top-0 left-0 bottom-0 z-[2] right-0 justify-center flex flex-col items-start p-3", children: [
        /* @__PURE__ */ jsx("p", { children: "100+ Success Stories" }),
        /* @__PURE__ */ jsx("h2", { className: "text-[38px] font-bold md:max-w-[600px]", children: "Building Smarter Construction Management Solutions" }),
        /* @__PURE__ */ jsxs("div", { className: "flex gap-3 mt-5", children: [
          /* @__PURE__ */ jsx(StandardLinkButton, { className: "text-black", link: "home", text: "Book A Demo" }),
          /* @__PURE__ */ jsx(StandardLinkButton, { className: "text-black bg-zinc-300 hover:bg-zinc-500 hover:gradient-0", link: "home", text: "Our Solutions" })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "absolute top-0 left-0 right-0 bottom-0 md:bg-gradient-to-t from-black to-transparent z-[1]" }),
      /* @__PURE__ */ jsxs("div", { className: "min-h-[90vh] relative w-full", children: [
        /* @__PURE__ */ jsx("div", { className: "absolute md:hidden top-0 left-0 right-0 bottom-0 bg-gradient-to-b from-primary via-transparent to-transparent z-[1]" }),
        /* @__PURE__ */ jsx("img", { className: "object-cover w-full h-full", src: "storage/img1.jpg" })
      ] })
    ] })
  ] }) });
}
export {
  Welcome as default
};
